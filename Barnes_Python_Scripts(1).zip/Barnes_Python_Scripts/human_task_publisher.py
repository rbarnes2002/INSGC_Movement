#!/usr/bin/env python3
"""
human_task_publisher.py
Publishes a human interruption task as JSON on a ROS2 topic.

This is intentionally message-type-lightweight (std_msgs/String) so you can wire it
into whatever allocator/driver you build next.

Example:
  python3 human_task_publisher.py --robot robot1 --urgency urgent --deadline-type hard --deadline-s 25

Topic default: /robot1/human_task
Payload example (JSON):
{
  "task_id": "human_1700",
  "urgency": "urgent",
  "deadline_type": "hard",
  "deadline_s": 25.0,
  "created_unix": 1234567890.0,
  "waypoints": [[2.0, 1.0], [4.0, 1.0]]
}
"""

import argparse
import json
import time
from typing import List, Tuple

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class HumanTaskPublisher(Node):
    def __init__(self, topic: str):
        super().__init__("human_task_publisher")
        self.pub = self.create_publisher(String, topic, 10)
        self.get_logger().info(f"Publishing human tasks on: {topic}")

    def publish_task(
        self,
        task_id: str,
        urgency: str,
        deadline_type: str,
        deadline_s: float,
        waypoints: List[Tuple[float, float]],
    ) -> None:
        payload = {
            "task_id": task_id,
            "urgency": urgency,                # "urgent" | "nonurgent"
            "deadline_type": deadline_type,    # "hard" | "soft"
            "deadline_s": float(deadline_s),   # seconds from now (interpretation up to your allocator)
            "created_unix": float(time.time()),
            "waypoints": [[float(x), float(y)] for (x, y) in waypoints],
        }
        msg = String()
        msg.data = json.dumps(payload)
        self.pub.publish(msg)
        self.get_logger().info(f"Published: {msg.data}")


def parse_waypoints(s: str) -> List[Tuple[float, float]]:
    # Format: "x1,y1;x2,y2;..."
    out: List[Tuple[float, float]] = []
    if not s.strip():
        return out
    for pair in s.split(";"):
        x_str, y_str = pair.split(",")
        out.append((float(x_str), float(y_str)))
    return out


def build_topic(robot: str) -> str:
    return f"/{robot}/human_task" if robot else "/human_task"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--robot", default="robot1")
    parser.add_argument("--topic", default=None)
    parser.add_argument("--urgency", choices=["urgent", "nonurgent"], default="urgent")
    parser.add_argument("--deadline-type", choices=["hard", "soft"], default="hard")
    parser.add_argument("--deadline-s", type=float, default=30.0)
    parser.add_argument("--task-id", default=None)
    parser.add_argument("--waypoints", default="2.0,0.0;4.0,0.0", help='Format: "x1,y1;x2,y2;..."')
    args = parser.parse_args()

    topic = args.topic if args.topic else build_topic(args.robot)
    task_id = args.task_id if args.task_id else f"human_{int(time.time())}"
    wpts = parse_waypoints(args.waypoints)

    rclpy.init()
    node = HumanTaskPublisher(topic)
    node.publish_task(task_id, args.urgency, args.deadline_type, args.deadline_s, wpts)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

