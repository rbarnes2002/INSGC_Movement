R. Barnes
INSGC
How do variations in simulated terrain properties affect task completion time, and positional accuracy for a differential-drive mobile robot?
This folder contains 4 Scripts:
1) task_motion_demo.py 
2) human_task_publisher.py
3) interrupt_allocator_demo.py
4) keyboard_human_interrupt.py

These 3 scripts work in conjunction with Emilio's robot, and must be ran with his robot. I am sure it could work with another differential drive robot but it must also be named 'robot 1' or changed in the scripts.

## Files

### 1) `task_motion_demo.py`
**What it does:**  
Publishes `geometry_msgs/Twist` to a `cmd_vel` topic so the robot visibly moves in Gazebo.

**Patterns supported:**
- `square`
- `zigzag`
- `both` (square then zigzag)

**Primary output:** Robot movement + console logs:
- `TASK_1 START/FINISH`
- `TASK_2 START/FINISH`

### 2) `human_task_publisher.py`
**What it does:**  
Publishes a **human-issued task** (as JSON) on a ROS2 topic using `std_msgs/String`.

**Fields included:**
- `task_id`
- `urgency` (`urgent` / `nonurgent`)
- `deadline_type` (`hard` / `soft`)
- `deadline_s` (seconds-from-now)
- `created_unix`
- `waypoints` (currently informational unless you extend logic)

This script **does not move the robot by itself**; it only injects an interruption signal.

### 3) `interrupt_allocator_demo.py`
**What it does:**  
Runs baseline tasks (square → zigzag loop) and **subscribes** to the human task topic.  
When a human task message arrives, it **preempts** baseline motion and executes a visible “interrupt behavior,” then resumes baseline.

This is the script that actually demonstrates **task switching due to human interruption**.

### 4) keyboard_human_interrupt.py
**What it does:**  
Allows a human operator to inject interruption tasks using keyboard presses.

**Key bindings**

Urgent interruptions  
- `a` → pause  
- `b` → move forward  
- `c` → move backward  

Non-urgent interruptions  
- `d` → pause  
- `e` → move forward  
- `f` → move backward  

Each keypress publishes a JSON message on `/robot1/human_task` containing:
- `task_id`
- `urgency` (urgent / nonurgent)
- `action` (pause / forward / backward)
- `created_unix`

This script does **not** move the robot by itself.
---

## Requirements

- Ubuntu + ROS2 Jazzy installed
- Gazebo Sim running your world
- Your ROS↔Gazebo bridge launched (your project launch file)
- Python 3 + `rclpy` (comes with ROS2 Jazzy)
- Scripts must be executable or run with `python3`

---

## Gazebo + Bridge Setup (high level)

1) Launch Gazebo world and press **Play** in the GUI.
2) Launch the ROS bridge (your `multi_robot_bridge.launch.py`).

> Important: If Gazebo is paused, the robot will not move even if `cmd_vel` is publishing.

---

## Key Topics Used

### Velocity command topics (the environment on the lab PC)
Your available topics look like:
- `/model/robot1/cmd_vel`
- `/model/robot2/cmd_vel`
- `/model/robot3/cmd_vel`
- `/model/robot4/cmd_vel`

For the one-robot demos here, we use:
- **`/model/robot1/cmd_vel`**

### Human task topic (default)
- **`/robot1/human_task`**

---

## Make Scripts Executable (one-time)

From the directory containing scripts:

```bash
chmod +x task_motion_demo.py human_task_publisher.py interrupt_allocator_demo.py


