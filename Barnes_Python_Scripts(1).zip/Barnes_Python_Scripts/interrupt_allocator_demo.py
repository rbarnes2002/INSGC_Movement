#!/usr/bin/env python3
"""
interrupt_allocator_demo.py

- Publishes to /model/robot1/cmd_vel (or whatever you pass)
- Subscribes to /robot1/human_task (std_msgs/String JSON payload)
- Baseline behavior: square then zigzag in a loop
- On human task message: preempt baseline and run an "interrupt behavior" for N seconds,
  then resume baseline.

This is a demo scaffold to prove task-level switching from a human interruption signal.
"""

#!/usr/bin/env python3
"""
interrupt_allocator_demo.py (updated for keyboard interrupts)

- Publishes Twist to a cmd_vel topic (default: /model/robot1/cmd_vel)
- Subscribes to /robot1/human_task (std_msgs/String JSON payload)
- Baseline behavior: square -> zigzag -> repeat
- On human task: ACK pause (visible), then run human action, then resume baseline

Expected JSON format (from keyboard_human_interrupt.py):
{
  "task_id": "...",
  "urgency": "urgent" | "nonurgent",
  "action": "pause" | "forward" | "backward",
  "created_unix": <unix timestamp>
}
"""

import argparse
import json
import math
import time
from dataclasses import dataclass
from typing import Optional

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist


@dataclass
class HumanTask:
    task_id: str
    urgency: str     # "urgent" | "nonurgent"
    action: str      # "pause" | "forward" | "backward"


class InterruptAllocatorDemo(Node):
    def __init__(
        self,
        cmd_topic: str,
        human_topic: str,
        hz: float,
        linear: float,
        angular: float,
        ack_pause_s: float,
        human_pause_urgent_s: float,
        human_pause_nonurgent_s: float,
        human_move_urgent_s: float,
        human_move_nonurgent_s: float,
    ):
        super().__init__("interrupt_allocator_demo")

        self.pub = self.create_publisher(Twist, cmd_topic, 10)
        self.sub = self.create_subscription(String, human_topic, self.on_human_task, 10)

        self.dt = 1.0 / hz
        self.linear = float(linear)
        self.angular = float(angular)

        # professor request #2: visible pause when interrupt is received
        self.ack_pause_s = float(ack_pause_s)

        # durations used for the *human action*
        self.human_pause_urgent_s = float(human_pause_urgent_s)
        self.human_pause_nonurgent_s = float(human_pause_nonurgent_s)
        self.human_move_urgent_s = float(human_move_urgent_s)
        self.human_move_nonurgent_s = float(human_move_nonurgent_s)

        self.pending_interrupt: Optional[HumanTask] = None
        self.is_in_interrupt = False

        self.get_logger().info(f"cmd_vel topic: {cmd_topic}")
        self.get_logger().info(f"human task topic: {human_topic}")
        self.get_logger().info("Baseline loop: square -> zigzag -> repeat")
        self.get_logger().info("Human actions: pause / forward / backward")
        self.get_logger().info(f"ACK pause on interrupt receive: {self.ack_pause_s:.1f}s")

    # ---------- ROS callbacks ----------
    def on_human_task(self, msg: String) -> None:
        try:
            data = json.loads(msg.data)
            task = HumanTask(
                task_id=str(data.get("task_id", "human_unknown")),
                urgency=str(data.get("urgency", "urgent")),
                action=str(data.get("action", "pause")),
            )

            # overwrite with newest interrupt (simple policy)
            self.pending_interrupt = task

            self.get_logger().warn(
                f"Received HUMAN TASK: id={task.task_id} urgency={task.urgency} action={task.action}"
            )
        except Exception as e:
            self.get_logger().error(f"Failed to parse human task JSON: {e}. Raw: {msg.data}")

    # ---------- Motion helpers ----------
    def publish_twist(self, v: float, w: float) -> None:
        t = Twist()
        t.linear.x = float(v)
        t.angular.z = float(w)
        self.pub.publish(t)

    def stop(self, seconds: float = 0.2) -> None:
        end = time.time() + seconds
        while time.time() < end:
            self.publish_twist(0.0, 0.0)
            rclpy.spin_once(self, timeout_sec=0.0)
            time.sleep(self.dt)

    def drive_for(self, v: float, w: float, seconds: float) -> None:
        end = time.time() + seconds
        while time.time() < end:
            # allow interrupts to be noticed during baseline motion
            rclpy.spin_once(self, timeout_sec=0.0)

            # if a human task arrives, break out to handle it
            if (not self.is_in_interrupt) and (self.pending_interrupt is not None):
                return

            self.publish_twist(v, w)
            time.sleep(self.dt)

    # ---------- Baseline tasks ----------
    def task_square(self, side_seconds: float = 3.0) -> None:
        self.get_logger().info("BASELINE TASK START: square")
        for i in range(4):
            self.get_logger().info(f"  square {i+1}/4 forward")
            self.drive_for(self.linear, 0.0, side_seconds)
            if self.pending_interrupt:
                self.get_logger().info("  preempting square due to human task")
                return
            self.stop(0.15)

            angle = math.pi / 2.0
            turn_time = angle / max(self.angular, 1e-6)
            self.get_logger().info(f"  square {i+1}/4 turn")
            self.drive_for(0.0, self.angular, turn_time)
            if self.pending_interrupt:
                self.get_logger().info("  preempting square due to human task")
                return
            self.stop(0.15)

        self.get_logger().info("BASELINE TASK FINISH: square")

    def task_zigzag(self, reps: int = 6, forward_seconds: float = 2.0, turn_seconds: float = 0.8) -> None:
        self.get_logger().info("BASELINE TASK START: zigzag")
        sign = 1.0
        for i in range(reps):
            self.get_logger().info(f"  zigzag {i+1}/{reps} forward")
            self.drive_for(self.linear, 0.0, forward_seconds)
            if self.pending_interrupt:
                self.get_logger().info("  preempting zigzag due to human task")
                return

            self.get_logger().info(f"  zigzag {i+1}/{reps} turn")
            self.drive_for(0.0, sign * (0.6 * self.angular), turn_seconds)
            if self.pending_interrupt:
                self.get_logger().info("  preempting zigzag due to human task")
                return

            sign *= -1.0
            self.stop(0.1)

        self.get_logger().info("BASELINE TASK FINISH: zigzag")

    # ---------- Human interrupt behavior ----------
    def run_interrupt_task(self, task: HumanTask) -> None:
        self.is_in_interrupt = True
        self.pending_interrupt = None  # consume it

        # professor request #2: visible ACK pause before executing human action
        self.get_logger().warn(f"INTERRUPT RECEIVED: {task.task_id} -> ACK pause {self.ack_pause_s:.1f}s")
        self.stop(self.ack_pause_s)

        urgent = (task.urgency == "urgent")

        if task.action == "pause":
            dur = self.human_pause_urgent_s if urgent else self.human_pause_nonurgent_s
            self.get_logger().warn(f"HUMAN ACTION: PAUSE for {dur:.1f}s (urgency={task.urgency})")
            self.stop(dur)

        elif task.action == "forward":
            dur = self.human_move_urgent_s if urgent else self.human_move_nonurgent_s
            self.get_logger().warn(f"HUMAN ACTION: FORWARD for {dur:.1f}s (urgency={task.urgency})")
            self.drive_for(0.7 * self.linear, 0.0, dur)
            self.stop(0.2)

        elif task.action == "backward":
            dur = self.human_move_urgent_s if urgent else self.human_move_nonurgent_s
            self.get_logger().warn(f"HUMAN ACTION: BACKWARD for {dur:.1f}s (urgency={task.urgency})")
            self.drive_for(-0.5 * self.linear, 0.0, dur)
            self.stop(0.2)

        else:
            self.get_logger().error(f"Unknown human action: {task.action}. Defaulting to short pause.")
            self.stop(1.0)

        self.get_logger().warn(f"INTERRUPT FINISH: {task.task_id}")
        self.is_in_interrupt = False

    # ---------- Main loop ----------
    def run(self) -> None:
        try:
            while rclpy.ok():
                if self.pending_interrupt is not None:
                    self.run_interrupt_task(self.pending_interrupt)
                    continue

                self.task_square()
                if self.pending_interrupt is not None:
                    continue
                self.stop(0.5)

                self.task_zigzag()
                if self.pending_interrupt is not None:
                    continue
                self.stop(0.5)

        finally:
            self.stop(0.5)
            self.get_logger().info("Stopped. Exiting.")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--cmd-topic", default="/model/robot1/cmd_vel")
    p.add_argument("--human-topic", default="/robot1/human_task")
    p.add_argument("--hz", type=float, default=20.0)
    p.add_argument("--linear", type=float, default=0.4)
    p.add_argument("--angular", type=float, default=1.2)

    # ACK pause (show receipt)
    p.add_argument("--ack-pause-s", type=float, default=1.0)

    # human action durations (urgent vs nonurgent)
    p.add_argument("--human-pause-urgent-s", type=float, default=4.0)
    p.add_argument("--human-pause-nonurgent-s", type=float, default=2.0)
    p.add_argument("--human-move-urgent-s", type=float, default=3.0)
    p.add_argument("--human-move-nonurgent-s", type=float, default=1.5)

    args = p.parse_args()

    rclpy.init()
    node = InterruptAllocatorDemo(
        cmd_topic=args.cmd_topic,
        human_topic=args.human_topic,
        hz=args.hz,
        linear=args.linear,
        angular=args.angular,
        ack_pause_s=args.ack_pause_s,
        human_pause_urgent_s=args.human_pause_urgent_s,
        human_pause_nonurgent_s=args.human_pause_nonurgent_s,
        human_move_urgent_s=args.human_move_urgent_s,
        human_move_nonurgent_s=args.human_move_nonurgent_s,
    )
    node.run()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

