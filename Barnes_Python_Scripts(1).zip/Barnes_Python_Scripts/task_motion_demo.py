#!/usr/bin/env python3
"""
task_motion_demo.py
ROS2 (rclpy) node to visibly move a robot by publishing geometry_msgs/Twist.

It runs a "task list" (e.g., TASK_1: square, TASK_2: zigzag) and logs task transitions
so you can show "robot begins doing tasks" in a demo or recording.

Usage examples:
  python3 task_motion_demo.py --robot robot1 --pattern square
  python3 task_motion_demo.py --robot robot1 --pattern zigzag
  python3 task_motion_demo.py --cmd-topic /robot1/cmd_vel --pattern square
"""

import argparse
import math
import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


class MotionTaskDemo(Node):
    def __init__(self, cmd_topic: str, linear: float, angular: float, hz: float, pattern: str):
        super().__init__("motion_task_demo")
        self.pub = self.create_publisher(Twist, cmd_topic, 10)

        self.linear = clamp(linear, 0.0, 2.0)
        self.angular = clamp(angular, 0.0, 6.0)
        self.dt = 1.0 / hz
        self.pattern = pattern

        self.get_logger().info(f"Publishing Twist to: {cmd_topic}")
        self.get_logger().info(f"Pattern={pattern} linear={self.linear:.2f} angular={self.angular:.2f} hz={hz:.1f}")

    def publish_twist(self, v: float, w: float) -> None:
        msg = Twist()
        msg.linear.x = float(v)
        msg.angular.z = float(w)
        self.pub.publish(msg)

    def stop(self, seconds: float = 0.25) -> None:
        end = time.time() + seconds
        while time.time() < end:
            self.publish_twist(0.0, 0.0)
            time.sleep(self.dt)

    def run_square(self, side_seconds: float = 3.0) -> None:
        """
        Square task: drive forward, turn ~90 deg, repeat 4 times.
        """
        self.get_logger().info("TASK_1 START: square")
        for i in range(4):
            # forward
            self.get_logger().info(f"  segment {i+1}/4: forward")
            end = time.time() + side_seconds
            while time.time() < end:
                self.publish_twist(self.linear, 0.0)
                time.sleep(self.dt)
            self.stop(0.2)

            # turn 90 deg: time = angle / angular
            angle = math.pi / 2.0
            turn_time = angle / max(self.angular, 1e-6)
            self.get_logger().info(f"  segment {i+1}/4: turn 90deg")
            end = time.time() + turn_time
            while time.time() < end:
                self.publish_twist(0.0, self.angular)
                time.sleep(self.dt)
            self.stop(0.2)

        self.get_logger().info("TASK_1 FINISH: square")

    def run_zigzag(self, reps: int = 6, forward_seconds: float = 2.0, turn_seconds: float = 0.8) -> None:
        """
        Zigzag task: forward, small left, forward, small right, repeat.
        """
        self.get_logger().info("TASK_2 START: zigzag")
        sign = 1.0
        for i in range(reps):
            self.get_logger().info(f"  zig {i+1}/{reps}: forward")
            end = time.time() + forward_seconds
            while time.time() < end:
                self.publish_twist(self.linear, 0.0)
                time.sleep(self.dt)

            self.get_logger().info(f"  zig {i+1}/{reps}: turn {'left' if sign > 0 else 'right'}")
            end = time.time() + turn_seconds
            while time.time() < end:
                self.publish_twist(0.0, sign * (0.6 * self.angular))
                time.sleep(self.dt)

            sign *= -1.0
            self.stop(0.15)

        self.get_logger().info("TASK_2 FINISH: zigzag")

    def run(self) -> None:
        try:
            if self.pattern == "square":
                self.run_square()
            elif self.pattern == "zigzag":
                self.run_zigzag()
            elif self.pattern == "both":
                self.run_square()
                self.stop(0.8)
                self.run_zigzag()
            else:
                raise ValueError(f"Unknown pattern: {self.pattern}")

        finally:
            self.stop(0.5)
            self.get_logger().info("Stopped. Exiting.")


def build_cmd_topic(robot: str) -> str:
    # Common patterns in multi-robot sims:
    #  - /robot1/cmd_vel
    #  - /cmd_vel (single robot)
    #  - /robot1/diff_drive/cmd_vel (plugin-specific)
    if robot:
        return f"/{robot}/cmd_vel"
    return "/cmd_vel"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--robot", default="robot1", help="Robot name for namespacing (e.g., robot1). Use '' for none.")
    parser.add_argument("--cmd-topic", default=None, help="Override cmd_vel topic (e.g., /robot1/cmd_vel).")
    parser.add_argument("--pattern", default="both", choices=["square", "zigzag", "both"])
    parser.add_argument("--linear", type=float, default=0.4)
    parser.add_argument("--angular", type=float, default=1.2)
    parser.add_argument("--hz", type=float, default=20.0)
    args = parser.parse_args()

    cmd_topic = args.cmd_topic if args.cmd_topic else build_cmd_topic(args.robot)

    rclpy.init()
    node = MotionTaskDemo(cmd_topic, args.linear, args.angular, args.hz, args.pattern)
    node.run()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

