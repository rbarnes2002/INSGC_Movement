#!/usr/bin/env python3
"""
keyboard_human_interrupt.py

Publishes human interruption tasks based on keypresses.

Key mapping (per professor):
  Urgent:     a, b, c
  Non-urgent: d, e, f

Actions:
  a/d -> pause
  b/e -> move forward
  c/f -> move backward

Publishes JSON on a ROS2 topic (std_msgs/String):
{
  "task_id": "...",
  "urgency": "urgent" | "nonurgent",
  "action": "pause" | "forward" | "backward",
  "created_unix": <time.time()>
}
"""

import json
import sys
import time
import termios
import tty

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


KEY_BINDINGS = {
    "a": ("urgent", "pause"),
    "b": ("urgent", "forward"),
    "c": ("urgent", "backward"),
    "d": ("nonurgent", "pause"),
    "e": ("nonurgent", "forward"),
    "f": ("nonurgent", "backward"),
}


def get_key() -> str:
    """Read a single keypress (raw mode)."""
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch


class KeyboardHumanInterrupt(Node):
    def __init__(self, topic: str):
        super().__init__("keyboard_human_interrupt")
        self.pub = self.create_publisher(String, topic, 10)

        self.get_logger().info(f"Publishing human interrupts on: {topic}")
        self.get_logger().info("Key bindings:")
        self.get_logger().info("  urgent:     a=PAUSE, b=FORWARD, c=BACKWARD")
        self.get_logger().info("  nonurgent:  d=PAUSE, e=FORWARD, f=BACKWARD")
        self.get_logger().info("Press 'q' to quit.")

    def publish_interrupt(self, urgency: str, action: str) -> None:
        payload = {
            "task_id": f"human_{int(time.time())}",
            "urgency": urgency,
            "action": action,
            "created_unix": float(time.time()),
        }
        msg = String()
        msg.data = json.dumps(payload)
        self.pub.publish(msg)
        self.get_logger().warn(f"SENT interrupt -> urgency={urgency} action={action}")

    def run(self) -> None:
        while rclpy.ok():
            key = get_key()

            if key == "q":
                self.get_logger().info("Quitting keyboard interrupt publisher.")
                return

            if key in KEY_BINDINGS:
                urgency, action = KEY_BINDINGS[key]
                self.publish_interrupt(urgency, action)


def main():
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("--topic", default="/robot1/human_task", help="Where to publish interruption JSON")
    args = p.parse_args()

    rclpy.init()
    node = KeyboardHumanInterrupt(args.topic)
    node.run()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

