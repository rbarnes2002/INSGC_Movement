#!/bin/bash

####################################
# Experiment Settings
####################################

NUM_ROBOTS=4
RUN_TIME=300

ORDER_TYPE="priority"
ADDRESS_TYPE="group"

DESKTOP="$HOME/Desktop"
ROS_WS="$DESKTOP/NASAprojSubTasks2/ros2_ws"
SIM_DIR="$DESKTOP/NASAprojSubTasks2/SpaceSim"

DATA_DIR="$DESKTOP/DATA_JULY/4_robot/Priority_Group"
OUTPUT_FILE="$DATA_DIR/example_data.csv"

mkdir -p "$DATA_DIR"

####################################
# Cleanup
####################################

cleanup() {

    echo ""
    echo "Stopping experiment..."

    kill $LOGGER_PID 2>/dev/null
    kill $SERVER_PID 2>/dev/null
    kill $BRIDGE_PID 2>/dev/null
    kill $SIM_PID 2>/dev/null

    for pid in "${ROBOT_PIDS[@]}"; do
        kill $pid 2>/dev/null
    done

    pkill -f "bot.py"
    pkill -f "server.py"
    pkill -f "multi_robot_bridge.launch.py"
    pkill -f "task_metrics_logger_V4.py"
    pkill -f "UserInputAllCases.py"

    echo "Experiment finished."

}

trap cleanup EXIT

####################################
# Gazebo (VISIBLE)
####################################

echo "Launching Gazebo..."

cd "$SIM_DIR"

gz sim moving_robot.sdf --verbose &
SIM_PID=$!

sleep 10

####################################
# ROS Bridge (HIDDEN)
####################################

echo "Launching ROS bridge..."

(
    cd "$ROS_WS"

    source install/setup.bash

    ros2 launch multi_robot_control multi_robot_bridge.launch.py

) > "$DESKTOP/bridge.log" 2>&1 &

BRIDGE_PID=$!

sleep 5

####################################
# Server (HIDDEN)
####################################

echo "Launching server..."

(
    cd "$DESKTOP"

    source /opt/ros/jazzy/setup.bash

    python3 server.py $NUM_ROBOTS

) > "$DESKTOP/server.log" 2>&1 &

SERVER_PID=$!

sleep 3

####################################
# Robots (HIDDEN)
####################################

echo "Launching robots..."

declare -a ROBOT_PIDS

robots=(
"robot1 -40 -80 priority"
"robot2 -60 -80 priority"
"robot3 -80 -80 priority"
"robot4 -50 -100 priority"
)

for robot in "${robots[@]}"
do

    name=$(echo "$robot" | awk '{print $1}')

    (
        cd "$DESKTOP"

        export ROS_LOG_DIR="./LOGS/$name"

        source /opt/ros/jazzy/setup.bash

        python3 bot.py $robot

    ) > "$DESKTOP/${name}.log" 2>&1 &

    ROBOT_PIDS+=($!)

    sleep 1

done

####################################
# Logger (HIDDEN)
####################################

echo "Launching logger..."

(
    cd "$DESKTOP"

    source /opt/ros/jazzy/setup.bash

    python3 task_metrics_logger_V4.py \
        --robot-topic /task_events \
        --human-topic /ServerPublish \
        --out "$OUTPUT_FILE" \
        --task-order-type priority \
        --experiment-run-time $RUN_TIME \
        --numOfBots $NUM_ROBOTS

) > "$DESKTOP/logger.log" 2>&1 &

LOGGER_PID=$!

sleep 3

####################################
# Participant Interface (VISIBLE)
####################################

echo "Launching participant interface..."

gnome-terminal -- bash -c "
cd $DESKTOP
source /opt/ros/jazzy/setup.bash

python3 UserInputAllCases.py \
    --numOfBots $NUM_ROBOTS \
    --task-order-type priority \
    --experiment-run-time $RUN_TIME \
    --experiment-address-type group \
    --add-task 'moveCardinalDirection north 5' \
    --add-task-prompt 'Move North 5 m'

exec bash
"

####################################
# Experiment Timer
####################################

echo ""
echo "======================================="
echo " Priority Group Experiment Running"
echo " Robots : $NUM_ROBOTS"
echo " Runtime: $RUN_TIME seconds"
echo "======================================="
echo ""

sleep $RUN_TIME

echo ""
echo "Time limit reached."
